

#ifndef __PN532_INTERFACE_H__
#define __PN532_INTERFACE_H__

#include <stdint.h>

// ---------------------------------------------------------------------------
// Interface selection
//
// The NFC_INTERFACE_* macros control which transport implementations
// (PN532_I2C / PN532_SPI / PN532_HSU / PN532_SWHSU) are compiled. They can be
// defined globally (e.g. `build_flags = -DNFC_INTERFACE_SPI` in PlatformIO)
// to build only the interfaces you need.
//
// When none of them is defined, I2C, SPI and HSU are compiled by default so
// that a plain `#include <PN532_I2C.h>` (etc.) links without any extra
// defines or build flags (issues #149, #163).
//
// SWHSU stays opt-in because it depends on SoftwareSerial, which is not
// available on every core: define NFC_INTERFACE_SWHSU (globally, or in your
// sketch together with `#include <PN532_SWHSU.cpp>`) to use it.
// ---------------------------------------------------------------------------
#if !defined(NFC_INTERFACE_I2C) && !defined(NFC_INTERFACE_SPI) && \
    !defined(NFC_INTERFACE_HSU) && !defined(NFC_INTERFACE_SWHSU)
#define NFC_INTERFACE_I2C
#define NFC_INTERFACE_SPI
#define NFC_INTERFACE_HSU
#endif

#define PN532_PREAMBLE                (0x00)
#define PN532_STARTCODE1              (0x00)
#define PN532_STARTCODE2              (0xFF)
#define PN532_POSTAMBLE               (0x00)

#define PN532_HOSTTOPN532             (0xD4)
#define PN532_PN532TOHOST             (0xD5)

#define PN532_ACK_WAIT_TIME           (10)  // ms, timeout of waiting for ACK

#define PN532_INVALID_ACK             (-1)
#define PN532_TIMEOUT                 (-2)
#define PN532_INVALID_FRAME           (-3)
#define PN532_NO_SPACE                (-4)

#define REVERSE_BITS_ORDER(b)         b = (b & 0xF0) >> 4 | (b & 0x0F) << 4; \
                                      b = (b & 0xCC) >> 2 | (b & 0x33) << 2; \
                                      b = (b & 0xAA) >> 1 | (b & 0x55) << 1

class PN532Interface
{
public:
    virtual void begin() = 0;
    virtual void wakeup() = 0;

    /**
    * @brief    write a command and check ack
    * @param    header  packet header
    * @param    hlen    length of header
    * @param    body    packet body
    * @param    blen    length of body
    * @return   0       success
    *           not 0   failed
    */
    virtual int8_t writeCommand(const uint8_t *header, uint8_t hlen, const uint8_t *body = 0, uint8_t blen = 0) = 0;

    /**
    * @brief    read the response of a command, strip prefix and suffix
    * @param    buf     to contain the response data
    * @param    len     lenght to read
    * @param    timeout max time to wait, 0 means no timeout
    * @return   >=0     length of response without prefix and suffix
    *           <0      failed to read response
    */
    virtual int16_t readResponse(uint8_t buf[], uint8_t len, uint16_t timeout = 1000) = 0;
};

#endif

